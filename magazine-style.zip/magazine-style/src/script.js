// Activate a modified Rellax plugin for the horizontal parallax affect 
var rellax = new Rellax('.parallax');

// Activate Morphext plugin for marquee animation
$("#js-rotating").Morphext({
  animation: "fadeInRight",
  speed: 3000,
  complete: function() {
    console.log("This is called after a phrase is animated in! Current phrase index: " + this.index);
  }
});